package com.genspark.SpringBootSecurityRevised;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSecurityRevisedApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSecurityRevisedApplication.class, args);
	}

}
