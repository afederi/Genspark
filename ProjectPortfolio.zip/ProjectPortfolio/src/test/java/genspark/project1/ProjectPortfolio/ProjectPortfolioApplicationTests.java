package genspark.project1.ProjectPortfolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectPortfolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
