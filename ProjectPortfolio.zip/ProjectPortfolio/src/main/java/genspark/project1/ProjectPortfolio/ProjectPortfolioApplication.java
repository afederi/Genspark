package genspark.project1.ProjectPortfolio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectPortfolioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectPortfolioApplication.class, args);
	}

}
