package com.genspark.SpringDemoSecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDemoSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDemoSecurityApplication.class, args);
	}

}
