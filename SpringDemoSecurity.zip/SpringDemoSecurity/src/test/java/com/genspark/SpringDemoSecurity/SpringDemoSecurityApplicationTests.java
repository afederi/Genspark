package com.genspark.SpringDemoSecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDemoSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
