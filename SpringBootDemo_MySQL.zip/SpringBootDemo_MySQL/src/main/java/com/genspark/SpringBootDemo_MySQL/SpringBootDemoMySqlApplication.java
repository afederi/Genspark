package com.genspark.SpringBootDemo_MySQL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDemoMySqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDemoMySqlApplication.class, args);
	}

}
