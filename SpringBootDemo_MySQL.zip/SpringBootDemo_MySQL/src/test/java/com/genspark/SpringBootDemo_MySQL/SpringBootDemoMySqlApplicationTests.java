package com.genspark.SpringBootDemo_MySQL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDemoMySqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
